#!/bin/sh
echo begin
support_hibernate()
{
	# check support pm-hibernate
	which pm-hibernate > /dev/null
	if [ "$?" -eq "0" ]; then
		echo pm-hibernate
		exit 0
	fi
	
	# check support s2disk
	which s2disk > /dev/null
	if [ "$?" -eq "0" ]; then
		echo s2disk
		exit 0
	fi

	# check support powersave
	which powersave > /dev/null
	if [ "$?" -eq "0" ]; then
		echo powersave
		exit 0
	fi
	
	exit 1
}
echo after1
hibernate()
{
	# check support pm-hibernate
	which pm-hibernate > /dev/null
	if [ "$?" -eq "0" ]; then
		pm-hibernate
		exit 0
	fi
	
	# check support s2disk
	which s2disk > /dev/null
	if [ "$?" -eq "0" ]; then
		s2disk
		exit 0
	fi

	# check support powersave
	which powersave > /dev/null
	if [ "$?" -eq "0" ]; then
		powersave -U
		exit 0
	fi
	
	exit 1
}

if [ $1 = "support" ]; then
	support_hibernate
else
	hibernate
fi